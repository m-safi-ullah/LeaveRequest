<?php
include 'DbConnect.php';
include 'Token.php';

header('Content-Type: application/json');

$dbConnection = new DbConnect();
$conn = $dbConnection->db();
if (!$conn) {
    die("Database connection failed");
}

$method = $_SERVER['REQUEST_METHOD'];
$HeaderToken = $_SERVER['HTTP_TOKEN'];
switch ($method) {
    case "POST":
        $token = Token::Verify($HeaderToken);
        if ($token) {
                try {
                    $portal = $_GET['portal'];
                    if($portal=== 'Admin'){
                        if(isset($_POST['oldPassword'])){
                            $sql = "SELECT Password FROM adminlogin WHERE Email = :Email";
                            $stmt = $conn->prepare($sql);
                            $stmt->bindParam(':Email', $_POST['Email']);
                            $stmt->execute();
                            $existingPassword = $stmt->fetchColumn();

                            if ($existingPassword == md5($_POST['oldPassword'])) {
                                $sql = "UPDATE adminlogin SET Password = md5(:newPassword)";
                                $stmt = $conn->prepare($sql);
                                $stmt->bindParam(':newPassword', $_POST['newPassword']);

                                if ($stmt->execute()) {
                                    $response = ['status' => 1, 'message' => 'Password updated successfully.'];
                                } else {
                                    $response = ['status' => 0, 'message' => 'Failed to update password.'];
                                }
                            } else {
                                $response = ['status' => 0, 'message' => 'Current password is incorrect.'];
                            }
                        }
                        else{
                            $sql = "UPDATE adminlogin SET Email = :newEmail WHERE Email = :currentEmail";
                            $stmt = $conn->prepare($sql);
                            $stmt->bindParam(':newEmail', $_POST['update-email']);
                            $stmt->bindParam(':currentEmail', $_POST['Email']);

                            if ($stmt->execute()) {
                                if ($stmt->rowCount() > 0) {
                                    $response = ['status' => 1, 'message' => 'Email updated successfully.'];
                                } else {
                                    $response = ['status' => 0, 'message' => 'No changes made. Check if the new email is the same as the current one.'];
                                }
                            } else {
                                $response = ['status' => 0, 'message' => 'Failed to update email.'];
                            }
                        }

                        echo json_encode($response);
                    }
                    else if($portal === 'Approver'){
                        $sql = "SELECT Password FROM leaveapprover WHERE Email = :Email";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindParam(':Email', $_POST['Email']);
                        $stmt->execute();
                        $existingPassword = $stmt->fetchColumn();
                        
                        if ($existingPassword == md5($_POST['oldPassword'])) {
                            $sql = "UPDATE leaveapprover SET Password = md5(:newPassword) WHERE Email = :Email";
                            $stmt = $conn->prepare($sql);
                            $stmt->bindParam(':Email', $_POST['Email']);
                            $stmt->bindParam(':newPassword', $_POST['newPassword']);
                            if ($stmt->execute()) {
                                $response = ['status' => 1, 'message' => 'Password updated successfully.'];
                            } else {
                                $response = ['status' => 0, 'message' => 'Failed to update password.'];
                            }
                        } else {
                            $response = ['status' => 0, 'message' => 'Current password is incorrect.'];
                        }
                        echo json_encode($response);
                    }
                    else{
                        $sql = "SELECT Password FROM emplogin WHERE Email = :Email";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindParam(':Email', $_POST['Email']);
                        $stmt->execute();
                        $existingPassword = $stmt->fetchColumn();

                        
                        if ($existingPassword == md5($_POST['oldPassword'])) {
                            $sql = "UPDATE emplogin SET Password = md5(:newPassword) WHERE Email = :Email";
                            $stmt = $conn->prepare($sql);
                            $stmt->bindParam(':Email', $_POST['Email']);
                            $stmt->bindParam(':newPassword', $_POST['newPassword']);
                            
                            if ($stmt->execute()) {
                                $response = ['status' => 1, 'message' => 'Password updated successfully.'];
                            } else {
                                $response = ['status' => 0, 'message' => 'Failed to update password.'];
                            }
                        } else {
                            $response = ['status' => 0, 'message' => 'Current password is incorrect.'];
                        }
                        echo json_encode($response);
                    }
                } catch (PDOException $e) {
                    http_response_code(500);
                    echo json_encode(['status' => 0, 'message' => 'Error: ' . $e->getMessage()]);
                }
                break;
            }
        else{
            echo json_encode(['status' => 0, 'message' => 'No Token Found']);
        }
}
?>
