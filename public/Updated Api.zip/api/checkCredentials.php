<?php

include 'DbConnect.php';
include 'Token.php';

$dbConnection = new DbConnect();
$conn = $dbConnection->db();
if (!$conn) {
    die("Database connection failed");
}
header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $user = json_decode(file_get_contents('php://input'), true);

    $portal = $_GET['portal'];

            if($portal == 'Admin')
            {
                $sql = "SELECT Name,Email FROM adminlogin WHERE Email = :username AND Password = md5(:password)";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':username', $user['username']);
                $stmt->bindParam(':password', $user['password']);
            }
            else if($portal == 'Approver')
            {
                $sql = "SELECT Name,Email FROM leaveapprover WHERE Email = :username AND Password = md5(:password)";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':username', $user['username']);
                $stmt->bindParam(':password', $user['password']);
            }
            else{
                $sql = "SELECT Name,Email FROM emplogin WHERE Email = :username AND Password = md5(:password)";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':username', $user['username']);
                $stmt->bindParam(':password', $user['password']);
            }

        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $token = Token::Sign(['data' => $row , 'portal' => $portal]);
            $response = [
                'status' => 1,
                'message' => 'Login Successful',
                'token' => $token['token'],
                'expire' => $token['expire'] 
            ];
            echo json_encode($response);
        } else {
            echo("Invalid credentials");
        }
} else {
    echo("Invalid request method");
}
?>


