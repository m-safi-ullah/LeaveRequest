<?php
include 'DbConnect.php';
$dbConnection = new DbConnect();
$conn = $dbConnection->db();
header('Content-Type: application/json');

if (!$conn) {
    die(json_encode(['status' => 0, 'message' => 'Database connection failed']));
}

$method = $_SERVER['REQUEST_METHOD'];
if ($method != "POST") {
    echo json_encode(['status' => 0, 'message' => 'Invalid request method']);
    exit;
}

$portal = $_GET['portal'];
$manipulation = $_GET['manipulation'];

switch ($manipulation) {
    case 'check-mail':
        $email = $_POST['email'];
        $sql = "SELECT Name FROM emplogin WHERE Email = :email";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $rowCount = $stmt->rowCount();

        if ($rowCount > 0) {
            $Name = $stmt->fetchColumn(); 
            $code = rand(999999, 111111);
            $updateSql = "UPDATE " . getTableName($portal) . " SET code = :code WHERE Email = :email";
            $stmt = $conn->prepare($updateSql);
            $stmt->bindParam(':code', $code);
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                $subject = "Email Verification Code";
                $message = "Hi " . $Name . ",

Thank you for your request to update your credentials.

Your verification code is $code.

Please enter this code on the provided field to proceed. Also, do not share this code with anyone.

If you did not request this change, please ignore this message or contact us immediately.

Best regards,
Catering Industries";

                $sender = "From: Leave@ciho.com";
                if (mail($email, $subject, $message, $sender)) {
                    echo json_encode(['status' => 1, 'message' => 'OTP Sent to your email']);
                } else {
                    echo json_encode(['status' => 0, 'message' => 'Error while sending OTP']);
                }
            } else {
                echo json_encode(['status' => 0, 'message' => 'Error while updating OTP code']);
            }
        } else {
            echo json_encode(['status' => 0, 'message' => 'No Record Found']);
        }
        break;
    case 'verify-otp':
        $code = $_POST['OTP'];
        
        $verifySql = "SELECT code FROM " . getTableName($portal) . " WHERE code = :code AND Email = :email";
        $stmt = $conn->prepare($verifySql);
        $stmt->bindParam(':code', $code);
        $stmt->bindParam(':email', $_POST['email']);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            echo json_encode(['status' => 1, 'message' => 'OTP Matched']);
        } else {
            echo json_encode(['status' => 0, 'message' => 'OTP Incorrect']);
        }
        break;

    case 'update-credentials':
        $password = $_POST['password'];
        $email = $_POST['email'];
        $code = $_POST['otp'];

        $checkSql = "SELECT code, Name FROM " . getTableName($portal) . " WHERE code = :code AND Email = :email";
        $stmt = $conn->prepare($checkSql);
        $stmt->bindParam(':code', $code);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0 && $code != 0) {
            $Name = $stmt->fetchColumn(1);
            $updateSql = "UPDATE " . getTableName($portal) . " SET Password = md5(:password) WHERE Email = :email";
            $stmt = $conn->prepare($updateSql);
            $stmt->bindParam(':password', $password);
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                echo json_encode(['status' => 1, 'message' => 'Record updated successfully']);
                $subject = "Password Updated Successfully";
                $message = "Hi " . $Name . ",

Your password has been updated successfully.

If you did not request this change, please ignore this message or contact us immediately.

Best regards,
Catering Industries";

                $sender = "From: Leave@ciho.com";
                mail($email, $subject, $message, $sender);
            } else {
                echo json_encode(['status' => 0, 'message' => 'Enter new and strong password']);
            }
        } else {
            echo json_encode(['status' => 0, 'message' => 'OTP is not correct']);
        }
        break;


    default:
        echo json_encode(['status' => 0, 'message' => 'Invalid manipulation request']);
        break;
}

function getTableName($portal) {
    switch ($portal) {
        case 'Employee':
            return 'emplogin';
        case 'Approver':
            return 'leaveapprover';
        default:
            return 'adminlogin';
    }
}
?>