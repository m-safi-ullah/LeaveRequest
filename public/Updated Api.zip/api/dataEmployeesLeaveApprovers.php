<?php
include 'DbConnect.php';
include 'Token.php';
$dbConnection = new DbConnect();
$conn = $dbConnection->db();
header('Content-Type: application/json');

if (!$conn) {
    die(json_encode(['status' => 0, 'message' => 'Database connection failed']));
}
$method = $_SERVER['REQUEST_METHOD'];
$HeaderToken = $_SERVER['HTTP_TOKEN'];

    switch ($method) {
        case "POST":
            $token = Token::Verify($HeaderToken);
            if ($token) {
                    $Portal = $_GET['portal'];
                    $Manipulation = $_GET['Manipulation'] ?? '';
                    try {
                        if($Portal == 'Approver')
                        {
                            // Insert Approver Data
                            if ($Manipulation == 'Insert') {
                                $sql = "SELECT Email FROM leaveapprover WHERE Email=:AppEmail";
                                $stmt = $conn->prepare($sql);
                                $stmt->bindParam(':AppEmail', $_POST['AppEmail']);
                                $stmt->execute();
                                $rowCount = $stmt->rowCount();
                                
                                if($rowCount == 0){
                                    $sql = "INSERT INTO leaveapprover (Name, Email, Password)
                                            VALUES (:AppName, :AppEmail, md5(:AppPass))";
                                    $stmt = $conn->prepare($sql);
                                    $stmt->bindParam(':AppName', $_POST['AppName']);
                                    $stmt->bindParam(':AppEmail', $_POST['AppEmail']);
                                    $stmt->bindParam(':AppPass', $_POST['AppPass']);
                
                                    if ($stmt->execute()) {
                                        $response = ['status' => 1, 'message' => 'Successfully.'];
                                        echo json_encode($response);
                                    }
                                }
                                else{
                                    $response = ['status' => 0, 'message' => 'Approver already exist'];
                                    echo json_encode($response);
                                }
                            }
                            // Update Approver Record
                            else{
                                $sql = "SELECT Email FROM leaveapprover WHERE Email=:AppEmail AND ID !=:AppId";
                                $stmt = $conn->prepare($sql);
                                $stmt->bindParam(':AppEmail', $_POST['AppEmail']);
                                $stmt->bindParam(':AppId', $_POST['AppId']);
                                $stmt->execute();
                                $rowCount = $stmt->rowCount();

                                if ($rowCount == 0) {      
                                    if ($_POST['AppPass'] != '') {
                                        $sql = "UPDATE leaveapprover SET Name=:AppName, Email=:AppEmail, Password=md5(:AppPass) WHERE ID=:AppId";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bindParam(':AppName', $_POST['AppName']);
                                        $stmt->bindParam(':AppEmail', $_POST['AppEmail']);
                                        $stmt->bindParam(':AppPass', $_POST['AppPass']);
                                        $stmt->bindParam(':AppId', $_POST['AppId']);
                                        if ($stmt->execute()) {
                                            $response = ['status' => 1, 'message' => 'Successfully.'];
                                            echo json_encode($response);
                                        }
                                    }
                                    else{
                                        $sql = "UPDATE leaveapprover SET Name=:AppName, Email=:AppEmail WHERE ID=:AppId";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bindParam(':AppName', $_POST['AppName']);
                                        $stmt->bindParam(':AppEmail', $_POST['AppEmail']);
                                        $stmt->bindParam(':AppId', $_POST['AppId']);
                                        if ($stmt->execute()) {
                                            $response = ['status' => 1, 'message' => 'Successfully.'];
                                            echo json_encode($response);
                                        }
                                    }    
                                }
                                else{
                                    $response = ['status' => 0, 'message' => 'Approver already exist'];
                                    echo json_encode($response);
                                }
                            }
                        }
                        elseif($Portal == 'Employee'){
                            //  Insert Employee Data
                            if($Manipulation == 'Insert'){
                                $sql = "SELECT Email FROM emplogin WHERE Email=:empEmail";
                                $stmt = $conn->prepare($sql);
                                $stmt->bindParam(':empEmail', $_POST['empEmail']);
                                $stmt->execute();
                                $rowCount = $stmt->rowCount();

                                if($rowCount == 0){
                                    $sql = "INSERT INTO emplogin (Name, Email, Password)
                                            VALUES (:empName, :empEmail, md5(:empPassword))";
                                    $stmt = $conn->prepare($sql);
                                    $stmt->bindParam(':empName', $_POST['empName']);
                                    $stmt->bindParam(':empEmail', $_POST['empEmail']);
                                    $stmt->bindParam(':empPassword', $_POST['empPassword']);
                                    if ($stmt->execute()) {
                                        $rowCount2 = $stmt->rowCount();
                                        $response = ['status' => 1, 'message' => 'Successfully.'];
                                        echo json_encode($response);
                                    }
                                } else {
                                    if ($stmt->execute()) {
                                        $response = ['status' => 1, 'message' => 'Employee already exist'];
                                        echo json_encode($response);
                                    }
                                }
                            }
                            //  Update Employee Data
                            else{
                                $sql = "SELECT Email FROM emplogin WHERE Email=:empEmail AND ID != :empID";
                                $stmt = $conn->prepare($sql);
                                $stmt->bindParam(':empEmail', $_POST['empEmail']);
                                $stmt->bindParam(':empID', $_POST['empID']);
                                $stmt->execute();
                                $rowCount = $stmt->rowCount();

                                if($rowCount == 0)
                                {
                                    if ($_POST['empPassword'] != '') {
                                        $sql = "UPDATE emplogin SET Name=:empName, Email=:empEmail, Password=md5(:empPassword) WHERE ID=:empID";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bindParam(':empName', $_POST['empName']);
                                        $stmt->bindParam(':empEmail', $_POST['empEmail']);
                                        $stmt->bindParam(':empPassword', $_POST['empPassword']);
                                        $stmt->bindParam(':empID', $_POST['empID']);
                                        if ($stmt->execute()) {
                                            $response = ['status' => 1, 'message' => 'Successfully.'];
                                            echo json_encode($response);
                                        }
                                    }
                                    else{
                                        $sql = "UPDATE emplogin SET Name=:empName, Email=:empEmail WHERE ID=:empID";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bindParam(':empName', $_POST['empName']);
                                        $stmt->bindParam(':empEmail', $_POST['empEmail']);
                                        $stmt->bindParam(':empID', $_POST['empID']);
                                        if ($stmt->execute()) {
                                            $response = ['status' => 1, 'message' => 'Successfully.'];
                                            echo json_encode($response);
                                        }
                                    }
                                }   
                                else {
                                    if ($stmt->execute()) {
                                        $response = ['status' => 1, 'message' => 'Employee already exist'];
                                        echo json_encode($response);
                                    }
                                }
                            }
                        }
                        else{
                            echo json_encode(['status' => 0, 'message' => 'Invalid Request']);
                        }
                    } catch (PDOException $e) {
                        http_response_code(500);
                        echo json_encode(['status' => 0, 'message' => 'Error: ' . $e->getMessage()]);
                    }
                }
            else{
                echo json_encode(['status' => 0, 'message' => 'No Token Found']);
            }
            break;
        case "GET":
            $token = Token::Verify($HeaderToken);
            if ($token) {
                try {
                    $Portal = $_GET['portal'];
                    if ($Portal == 'Approver') {
                        $sql = "SELECT ID, Name, Email FROM leaveapprover";
                        $stmt = $conn->prepare($sql);
                    } elseif ($Portal == 'Employee') {
                        $sql = "SELECT ID, Name, Email FROM emplogin";
                        $stmt = $conn->prepare($sql);
                    }
                    if ($stmt->execute()) {
                        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        $response = ['status' => 1, 'data' => $data];
                        echo json_encode($response);
                    }
                } catch (PDOException $e) {
                    http_response_code(500);
                    echo json_encode(['status' => 0, 'message' => 'Error: ' . $e->getMessage()]);
                }
            }else{
                echo json_encode(['status' => 0, 'message' => 'No Tokens Found']);
            }
            break;
        case "DELETE":
        $token = Token::Verify($HeaderToken);
            if ($token) {
                try {
                    $user = json_decode(file_get_contents('php://input'), true);
                    $Portal = $_GET['portal'];
                    if ($Portal == 'Approver') {
                        $sql = "DELETE FROM leaveapprover WHERE ID=:ID";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindParam(':ID', $user['ID']);
                    } elseif ($Portal == 'Employee') {
                        $sql = "DELETE FROM emplogin WHERE ID=:ID";
                        $stmt = $conn->prepare($sql);
                        $stmt->bindParam(':ID', $user['ID']);
                    }
                    if ($stmt->execute()) {
                        $response = ['status' => 1, 'message' => 'Record deleted successfully.'];
                        echo json_encode($response);
                    }
                } catch (PDOException $e) {
                    http_response_code(500);
                    echo json_encode(['status' => 0, 'message' => 'Error: ' . $e->getMessage()]);
                }
            }
            else{
                echo json_encode(['status' => 0, 'message' => 'No Token Found']);
            }
            break;
    }

?>
