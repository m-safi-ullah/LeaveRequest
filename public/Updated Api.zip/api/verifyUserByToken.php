<?php
header("Access-Control-Allow-Origin:* ");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

include 'Token.php';

// $headers = getallheaders();
// if (!isset($headers['Authorization'])) {
//     http_response_code(400);
//     echo json_encode(['valid' => false, 'message' => 'Authorization header is required']);
//     exit;
// }

// $token = $headers['Token'];

$token = $_GET['token'];

$payload = Token::Verify($token);
if (!$payload) {
    // http_response_code(401);
    echo json_encode(['valid' => false, 'message' => 'Invalid token']);
    exit;
}

$user = [
    'role' => $payload['portal'],
];

http_response_code(200);
echo json_encode([
    'valid' => true,
    'role' => $user['role'],
    'data' => $payload,
]);
