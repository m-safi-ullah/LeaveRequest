<?php
header("Access-Control-Allow-Origin:* ");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");

class DbConnect {
    private $server = 'localhost';
    private $dbname = 'cihobgzz_leaverequest';
    private $user = 'cihobgzz_leaverequest';
    private $pass = 'NMTWxhnMnXFWvc6TngbZ';
    private $conn;

    function __construct() {
        $this->connect();
    }

    protected function connect() {
        try {
            $this->conn = new PDO("mysql:host={$this->server};dbname={$this->dbname}", $this->user, $this->pass);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }

    function __destruct() {
        if ($this->conn) {
            $this->conn = null;
        }
    }

    function db() {
		
        if (!$this->conn) {
            $this->connect();
        }
        return $this->conn;
    }
}
?>

