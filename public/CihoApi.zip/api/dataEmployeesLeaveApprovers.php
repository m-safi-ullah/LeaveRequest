<?php
include 'DbConnect.php';

$dbConnection = new DbConnect();
$conn = $dbConnection->db();
if (!$conn) {
    die("Database connection failed");
}

$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case "POST":
        $portal = $_GET['portal'];
        $Manipulation = $_GET['Manipulation'] ?? '';
        $ID = $_GET['ID'] ?? '';
        
        try {
            if ($portal == 'Approver' && $Manipulation == 'Insert') {
                $sql = "INSERT INTO leaveapprover (Name, Email, Password)
                        VALUES (:AppName, :AppEmail, md5(:AppPass))";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':AppName', $_POST['AppName']);
                $stmt->bindParam(':AppEmail', $_POST['AppEmail']);
                $stmt->bindParam(':AppPass', $_POST['AppPass']);
            }elseif ($portal == 'Approver' && $Manipulation == 'Update') {
                $sql = "SELECT Password FROM leaveapprover WHERE ID = :AppId";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':AppId', $_POST['AppId']);
                $stmt->execute();
                $existingPassword = $stmt->fetchColumn();

                if ($existingPassword !== $_POST['AppPass']) {
                    $sql = "UPDATE leaveapprover SET Name=:AppName, Email=:AppEmail, Password=md5(:AppPass) WHERE ID=:AppId";
                    $stmt = $conn->prepare($sql);
                    $stmt->bindParam(':AppName', $_POST['AppName']);
                    $stmt->bindParam(':AppEmail', $_POST['AppEmail']);
                    $stmt->bindParam(':AppPass', $_POST['AppPass']);
                    $stmt->bindParam(':AppId', $_POST['AppId']);
                    $stmt->execute();
                }
                else{
                    $sql = "UPDATE leaveapprover SET Name=:AppName, Email=:AppEmail WHERE ID=:AppId";
                    $stmt = $conn->prepare($sql);
                    $stmt->bindParam(':AppName', $_POST['AppName']);
                    $stmt->bindParam(':AppEmail', $_POST['AppEmail']);
                    $stmt->bindParam(':AppId', $_POST['AppId']);
                    $stmt->execute();
                }
            }elseif ($portal == 'Employee' && $Manipulation == 'Update') {
                $sql = "SELECT Password FROM emplogin WHERE ID = :empID";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':empID', $_POST['empID']);
                $stmt->execute();
                $existingPassword = $stmt->fetchColumn();

                if ($existingPassword !== $_POST['empPassword']) {
                    $sql = "UPDATE emplogin SET Name=:empName, Email=:empEmail, Password=md5(:empPassword) WHERE ID=:empID";
                    $stmt = $conn->prepare($sql);
                    $stmt->bindParam(':empName', $_POST['empName']);
                    $stmt->bindParam(':empEmail', $_POST['empEmail']);
                    $stmt->bindParam(':empPassword', $_POST['empPassword']);
                    $stmt->bindParam(':empID', $_POST['empID']);
                    $stmt->execute();
                }
                else{
                    $sql = "UPDATE emplogin SET Name=:empName, Email=:empEmail WHERE ID=:empID";
                    $stmt = $conn->prepare($sql);
                    $stmt->bindParam(':empName', $_POST['empName']);
                    $stmt->bindParam(':empEmail', $_POST['empEmail']);
                    $stmt->bindParam(':empID', $_POST['empID']);
                    $stmt->execute();
                }
            } elseif ($portal == 'Employee' && $Manipulation == 'Insert') {
                $sql = "INSERT INTO emplogin (Name, Email, Password)
                        VALUES (:empName, :empEmail, md5(:empPassword))";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':empName', $_POST['empName']);
                $stmt->bindParam(':empEmail', $_POST['empEmail']);
                $stmt->bindParam(':empPassword', $_POST['empPassword']);
            }
            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Successfully.'];
                echo json_encode($response);
            } else {
                $response = ['status' => 0, 'message' => 'Failed to create record.'];
                echo json_encode($response);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['status' => 0, 'message' => 'Error: ' . $e->getMessage()]);
        }
        break;
    case "GET":
        try {
            $portal = $_GET['portal'];
            if ($portal == 'Approver') {
                $sql = "SELECT * FROM leaveapprover";
                $stmt = $conn->prepare($sql);
            } elseif ($portal == 'Employee') {
                $sql = "SELECT * FROM emplogin";
                $stmt = $conn->prepare($sql);
            } else {
                $sql = "SELECT ID, Email, Name FROM emplogin";
                $stmt = $conn->prepare($sql);
            }
            if ($stmt->execute()) {
                $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $response = ['status' => 1, 'data' => $data];
                echo json_encode($response);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['status' => 0, 'message' => 'Error: ' . $e->getMessage()]);
        }
        break;
    case "DELETE":
        try {
            $user = json_decode(file_get_contents('php://input'), true);
            $portal = $_GET['portal'];
            if ($portal == 'Approver') {
                $sql = "DELETE FROM leaveapprover WHERE ID=:appID";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':appID', $user['appID']);
            } elseif ($portal == 'Employee') {
                $sql = "DELETE FROM emplogin WHERE ID=:empID";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':empID', $user['empID']);
            }
            if ($stmt->execute()) {
                $response = ['status' => 1, 'message' => 'Record deleted successfully.'];
                echo json_encode($response);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['status' => 0, 'message' => 'Error: ' . $e->getMessage()]);
        }
        break;
}
?>
