<?php

include 'DbConnect.php';

$dbConnection = new DbConnect();
$conn = $dbConnection->db();
if (!$conn) {
    die("Database connection failed");
}
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $user = json_decode(file_get_contents('php://input'), true);

    $portal = $_GET['portal'];

            if($portal == 'Admin')
            {
                $sql = "SELECT Name FROM adminlogin WHERE Email = :username AND Password = md5(:password)";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':username', $user['username']);
                $stmt->bindParam(':password', $user['password']);
            }
            else if($portal == 'Approver')
            {
                $sql = "SELECT Name FROM leaveapprover WHERE Email = :username AND Password = md5(:password)";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':username', $user['username']);
                $stmt->bindParam(':password', $user['password']);
            }
            else{
                $sql = "SELECT Name FROM emplogin WHERE Email = :username AND Password = md5(:password)";
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':username', $user['username']);
                $stmt->bindParam(':password', $user['password']);
            }

        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $response = ['status' => 1, 'message' => 'Successfully.' , 'data' => $row];
            echo json_encode($response);
        } else {
            echo("Invalid credentials");
        }
} else {
    echo("Invalid request method");
}
?>


