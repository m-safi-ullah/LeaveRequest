<?php

function sendMailToHead($user) {
    $attachmentUrl = "https://ciho.com.au/api/uploads/".$user['DocumentImg'];
    $to1 = "Dee@cateringindustries.com.au";
    $subject1 = "Approved Leave Request";
    $messageContent = "<html><body>";
    $messageContent .= "<h3>Leave Request Details</h3>";
    $messageContent .= "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
    $messageContent .= "<tr><th colspan='2'>Employee Details</th></tr>";
    $messageContent .= "<tr><td><strong>Name:</strong></td><td>" . $user['FirstName'] . " " . $user['LastName'] . "</td></tr>";
    $messageContent .= "<tr><td><strong>Email:</strong></td><td>" . $user['Email'] . "</td></tr>";
    $messageContent .= "<tr><td><strong>Leave Type:</strong></td><td>" . $user['LeaveType'] . "</td></tr>";
    $messageContent .= "<tr><td><strong>First Date of Absence:</strong></td><td>" . $user['FDate'] . "</td></tr>";
    $messageContent .= "<tr><td><strong>Last Date of Absence:</strong></td><td>" . $user['LDate'] . "</td></tr>";
    $messageContent .= "<tr><td><strong>Total Leave Days:</strong></td><td>" . $user['TDate'] . "</td></tr>";
    $messageContent .= "<tr><td><strong>Leave Approver:</strong></td><td>" . $user['LeaveApprover'] . "</td></tr>";
    $messageContent .= "<tr><td><strong>Attachment Link:</strong></td><td><a href=\"" . $attachmentUrl . "\">Preview Attachment</a></td></tr>";
    $messageContent .= "<tr><td><strong>Message:</strong></td><td>" . $user['Comments'] . "</td></tr>";
    $messageContent .= "</table>";
    $messageContent .= "</body></html>";

    $headers = "From: Leave@Ciho.com.au\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    if(mail($to1, $subject1, $messageContent, $headers)){
        $response = ['status' => 1, 'message' => 'Successfully updated and email sent.'];
        echo json_encode($response);
    }
}

?>